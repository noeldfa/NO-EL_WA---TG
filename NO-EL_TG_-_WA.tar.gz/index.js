
console.log("FILE STARTED");

require('dotenv').config();

const { Telegraf } = require('telegraf');
const fs = require('fs/promises');
const path = require('path');

/* ================== ENV ================== */

const BOT_TOKEN = process.env.BOT_TOKEN;
const OWNER_ID = Number(process.env.OWNER_ID);

if (!BOT_TOKEN) throw new Error("Missing BOT_TOKEN");

/* ================== STATE ================== */

const bot = new Telegraf(BOT_TOKEN);

const activeSockets = new Map();
global.activeSockets = activeSockets;

const assignments = new Map();      // sessionKey -> telegram group
const messagingState = new Map();   // sessionKey -> on/off
const premiumUsers = new Set();     // user IDs

/* ================== PATHS ================== */

const DB_PATH = './database';
const SESS_PATH = path.join(DB_PATH, 'sessions');
const ASSIGN_FILE = path.join(DB_PATH, 'assignments.json');
const PREM_FILE = path.join(DB_PATH, 'premium.json');

/* ================== UTIL ================== */

async function ensureDirs() {
    await fs.mkdir(SESS_PATH, { recursive: true });
}

async function loadJSON(file, fallback) {
    try {
        return JSON.parse(await fs.readFile(file));
    } catch {
        return fallback;
    }
}

async function saveJSON(file, data) {
    await fs.writeFile(file, JSON.stringify(data, null, 2));
}

/* ================== LOAD DATA ================== */

async function loadData() {
    const assignData = await loadJSON(ASSIGN_FILE, {});

    Object.entries(assignData).forEach(([k, v]) => {
        assignments.set(k, v.groupId);
        messagingState.set(k, v.enabled);
    });

    const premData = await loadJSON(PREM_FILE, []);
    premData.forEach(id => premiumUsers.add(id));
}

/* ================== MODULES ================== */

const waManager = require('./waManager');
const commands = require('./commands');
const groups = require('./groups');
const inbox = require('./inbox');
const statuses = require('./statuses');

/* ================== INIT MODULES ================== */

waManager.init({
    bot,
    activeSockets,
    assignments,
    messagingState
});

groups.init({
    bot,
    assignments,
    messagingState
});

inbox.init({
    bot,
    assignments,
    messagingState
});

statuses.init({
    bot,
    assignments,
    messagingState
});

commands.init({
    bot,
    waManager,
    assignments,
    messagingState,
    premiumUsers,
    OWNER_ID,

    saveAssignments: () => saveJSON(
        ASSIGN_FILE,
        Object.fromEntries(
            [...assignments.entries()].map(([k, v]) => [k, {
                groupId: v,
                enabled: messagingState.get(k)
            }])
        )
    ),

    savePremium: () => saveJSON(PREM_FILE, [...premiumUsers])
});

/* ================== RESTORE SESSIONS ================== */

async function restoreSessions() {
    try {
        const dirs = await fs.readdir(SESS_PATH);

        for (const dir of dirs) {
            if (!dir.includes('_')) continue;

            const [chatId, number] = dir.split('_');

            setTimeout(() => {
                waManager.start(Number(chatId), number, true);
            }, 2000);
        }
    } catch (err) {
        console.error("Restore error:", err.message);
    }
}

/* ================== START ================== */
setInterval(async () => {
    try {
        const res = await bot.telegram.getMe();
        console.log("PING OK:", res.username);
    } catch (e) {
        console.log("PING FAIL:", e.message);
    }
}, 180000); // every 60s
/* ================== START BOT ================== */

(async () => {
    try {
        console.log("🚀 Starting bot...");

        await bot.telegram.deleteWebhook({
            drop_pending_updates: true
        });

        bot.launch()
            .then(() => console.log("🤖 Bot Online"))
            .catch(err => console.error("Launch error:", err));

        bot.on('message', (ctx) => {
            console.log("📩 MESSAGE:", ctx.message?.text);
        });

    } catch (err) {
        console.error("❌ STARTUP ERROR:", err);
    }
})();